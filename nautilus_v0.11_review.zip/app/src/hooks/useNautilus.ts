import { useEffect, useState, useCallback } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { PublicKey } from '@solana/web3.js';
import { Program, AnchorProvider, BN } from '@coral-xyz/anchor';
import { getAssociatedTokenAddress, getAccount } from '@solana/spl-token';
import { STATE_ADDRESS, PRICE_TABLE } from '../constants';
import idl from '../idl.json';

export interface NautilusState {
  currentStage: number;
  totalSold: number;
  treasuryBalance: number;
  buyPrice: number;
  sellPrice: number;
  mint: PublicKey;
}

export function useNautilus() {
  const { connection } = useConnection();
  const wallet = useWallet();

  const [state, setState] = useState<NautilusState | null>(null);
  const [tokenBalance, setTokenBalance] = useState<number>(0);
  const [solBalance, setSolBalance] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getProgram = useCallback(() => {
    if (!wallet.publicKey || !wallet.signTransaction || !wallet.signAllTransactions) return null;
    const provider = new AnchorProvider(connection, wallet as any, { commitment: 'confirmed' });
    return new Program(idl as any, provider);
  }, [connection, wallet]);

  const fetchState = useCallback(async () => {
    try {
      const provider = new AnchorProvider(connection, {} as any, { commitment: 'confirmed' });
      const program = new Program(idl as any, provider);
      const s = await (program.account as any).nautilusState.fetch(STATE_ADDRESS);

      const stage = s.currentStage;
      const totalSold = s.totalSold.toNumber();
      const treasuryBalance = s.treasuryBalance.toNumber();
      const buyPrice = PRICE_TABLE[stage];
      const sellPrice = totalSold === 0 ? 0 : Math.floor(treasuryBalance / totalSold);
      const mint = s.mint as PublicKey;

      setState({ currentStage: stage, totalSold, treasuryBalance, buyPrice, sellPrice, mint });
    } catch {
      setError('Failed to fetch protocol state');
    }
  }, [connection]);

  const fetchBalances = useCallback(async () => {
    if (!wallet.publicKey || !state) return;
    try {
      const sol = await connection.getBalance(wallet.publicKey);
      setSolBalance(sol);
      const ata = await getAssociatedTokenAddress(state.mint, wallet.publicKey);
      try {
        const tokenAccount = await getAccount(connection, ata);
        setTokenBalance(Number(tokenAccount.amount));
      } catch {
        setTokenBalance(0);
      }
    } catch {
      setSolBalance(0);
      setTokenBalance(0);
    }
  }, [connection, wallet.publicKey, state]);

  const buy = useCallback(async (amount: number, confirmedStage?: number) => {
    const program = getProgram();
    if (!program || !wallet.publicKey || !state) throw new Error('Wallet not connected');
    setLoading(true);
    setError(null);
    try {
      // Re-fetch state immediately before submitting to detect stage advances.
      // If the stage changed since the user saw the price, throw a StageChanged error
      // so the UI can prompt for confirmation before proceeding.
      const provider = new AnchorProvider(connection, {} as any, { commitment: 'confirmed' });
      const freshProgram = new Program(idl as any, provider);
      const fresh = await (freshProgram.account as any).nautilusState.fetch(STATE_ADDRESS);
      const freshStage = fresh.currentStage;
      if (confirmedStage === undefined && freshStage !== state.currentStage) {
        const freshBuyPrice = PRICE_TABLE[freshStage];
        throw Object.assign(
          new Error('StageChanged'),
          { freshStage, freshBuyPrice }
        );
      }

      let remaining = amount;
      while (remaining > 0) {
        const chunk = Math.min(remaining, 100_000);
        await program.methods
          .buy(new BN(chunk))
          .accounts({ state: STATE_ADDRESS, mint: state.mint, buyer: wallet.publicKey })
          .rpc();
        remaining -= chunk;
      }
      await fetchState();
      await fetchBalances();
    } finally {
      setLoading(false);
    }
  }, [getProgram, wallet.publicKey, state, fetchState, fetchBalances, connection]);

  const sell = useCallback(async (amount: number) => {
    const program = getProgram();
    if (!program || !wallet.publicKey || !state) throw new Error('Wallet not connected');
    setLoading(true);
    setError(null);
    try {
      let remaining = amount;
      while (remaining > 0) {
        const chunk = Math.min(remaining, 100_000);
        await program.methods
          .sell(new BN(chunk))
          .accounts({ state: STATE_ADDRESS, mint: state.mint, seller: wallet.publicKey })
          .rpc();
        remaining -= chunk;
      }
      await fetchState();
      await fetchBalances();
    } finally {
      setLoading(false);
    }
  }, [getProgram, wallet.publicKey, state, fetchState, fetchBalances]);

  useEffect(() => {
    fetchState();
    const interval = setInterval(fetchState, 30000);
    return () => clearInterval(interval);
  }, [fetchState]);

  useEffect(() => {
    if (wallet.publicKey && state) fetchBalances();
  }, [wallet.publicKey, state, fetchBalances]);

  return { state, tokenBalance, solBalance, loading, error, buy, sell, refresh: fetchState };
}